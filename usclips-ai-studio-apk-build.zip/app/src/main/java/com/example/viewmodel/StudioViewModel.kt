package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.data.TemplateCatalog
import com.example.model.AIVideoGenerationRequest
import com.example.model.AudioTrack
import com.example.model.CaptionItem
import com.example.model.ExportConfig
import com.example.model.GeneratedCaptionBundle
import com.example.model.GeneratedScriptHook
import com.example.model.TemplateItem
import com.example.model.TextOverlay
import com.example.model.VideoClip
import com.example.model.VideoProject
import com.example.model.VideoStyle
import com.example.model.VoiceoverSettings
import com.example.service.AIToolsService
import com.example.service.VideoExporter
import com.example.service.VoiceoverEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed class StudioScreen {
    object Home : StudioScreen()
    object Editor : StudioScreen()
    object AIVideoGen : StudioScreen()
    object AnimeTemplates : StudioScreen()
    object UsaTemplates : StudioScreen()
    object MyProjects : StudioScreen()
    object AITools : StudioScreen()
}

enum class EditorToolTab {
    TRIM, SPLIT, TEXT, MUSIC, CAPTIONS, EXPORT
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)
    private val voiceoverEngine = VoiceoverEngine(application)
    private val videoExporter = VideoExporter(application)

    val projects = repository.projects
    val activeProject = repository.activeProject

    private val _currentScreen = MutableStateFlow<StudioScreen>(StudioScreen.Home)
    val currentScreen: StateFlow<StudioScreen> = _currentScreen.asStateFlow()

    private val _activeToolTab = MutableStateFlow(EditorToolTab.TRIM)
    val activeToolTab: StateFlow<EditorToolTab> = _activeToolTab.asStateFlow()

    // Playback state
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playheadSec = MutableStateFlow(0.0)
    val playheadSec: StateFlow<Double> = _playheadSec.asStateFlow()

    private var playbackJob: Job? = null

    // Export State
    private val _exportState = MutableStateFlow<VideoExporter.ExportState>(VideoExporter.ExportState.Idle)
    val exportState: StateFlow<VideoExporter.ExportState> = _exportState.asStateFlow()

    // AI Tools State
    private val _hookQuery = MutableStateFlow("insane tech secrets")
    val hookQuery: StateFlow<String> = _hookQuery.asStateFlow()

    private val _generatedHooks = MutableStateFlow<List<GeneratedScriptHook>>(
        AIToolsService.generateViralHooks("insane tech secrets")
    )
    val generatedHooks: StateFlow<List<GeneratedScriptHook>> = _generatedHooks.asStateFlow()

    private val _captionTopic = MutableStateFlow("Cyberpunk 2077 Anime Edit")
    val captionTopic: StateFlow<String> = _captionTopic.asStateFlow()

    private val _generatedCaptions = MutableStateFlow<GeneratedCaptionBundle>(
        AIToolsService.generateTitlesAndCaptions("Cyberpunk 2077 Anime Edit", "Anime")
    )
    val generatedCaptions: StateFlow<GeneratedCaptionBundle> = _generatedCaptions.asStateFlow()

    // AI Video Generation State
    private val _aiGenPrompt = MutableStateFlow("A futuristic anime cyborg samurai standing on a neon rain skyscraper in Tokyo")
    val aiGenPrompt: StateFlow<String> = _aiGenPrompt.asStateFlow()

    private val _aiGenStyle = MutableStateFlow(VideoStyle.ANIME_CINEMATIC)
    val aiGenStyle: StateFlow<VideoStyle> = _aiGenStyle.asStateFlow()

    private val _aiGenDuration = MutableStateFlow(10)
    val aiGenDuration: StateFlow<Int> = _aiGenDuration.asStateFlow()

    private val _isGeneratingAIVideo = MutableStateFlow(false)
    val isGeneratingAIVideo: StateFlow<Boolean> = _isGeneratingAIVideo.asStateFlow()

    private val _aiGenStatusMessage = MutableStateFlow<String?>(null)
    val aiGenStatusMessage: StateFlow<String?> = _aiGenStatusMessage.asStateFlow()

    private val _aiGenResultProject = MutableStateFlow<VideoProject?>(null)
    val aiGenResultProject: StateFlow<VideoProject?> = _aiGenResultProject.asStateFlow()

    // Voiceover TTS engine states
    val isTtsSpeaking = voiceoverEngine.isSpeaking
    val isTtsReady = voiceoverEngine.isReady
    val ttsStatus = voiceoverEngine.statusMessage
    private val _voiceoverSettings = MutableStateFlow(VoiceoverSettings())
    val voiceoverSettings: StateFlow<VoiceoverSettings> = _voiceoverSettings.asStateFlow()

    // Screen navigation
    fun navigateTo(screen: StudioScreen) {
        pausePlayback()
        _currentScreen.value = screen
    }

    fun setToolTab(tab: EditorToolTab) {
        _activeToolTab.value = tab
    }

    // Projects CRUD
    fun openProjectInEditor(project: VideoProject) {
        repository.setActiveProject(project)
        _playheadSec.value = project.trimStartSec
        navigateTo(StudioScreen.Editor)
    }

    fun createNewProject(title: String = "Viral 9:16 Short", videoUri: String? = null) {
        val proj = repository.createNewProject(title = title, videoUri = videoUri)
        _playheadSec.value = 0.0
        navigateTo(StudioScreen.Editor)
    }

    fun applyTemplate(template: TemplateItem) {
        val proj = repository.createFromTemplate(template)
        _playheadSec.value = 0.0
        navigateTo(StudioScreen.Editor)
    }

    fun deleteProject(id: String) {
        repository.deleteProject(id)
    }

    fun duplicateProject(id: String) {
        repository.duplicateProject(id)
    }

    // Video Playback & Timeline Controls
    fun togglePlayPause() {
        if (_isPlaying.value) {
            pausePlayback()
        } else {
            startPlayback()
        }
    }

    private fun startPlayback() {
        val project = activeProject.value ?: return
        val endLimit = project.trimEndSec.coerceAtMost(project.durationSec)
        if (_playheadSec.value >= endLimit) {
            _playheadSec.value = project.trimStartSec
        }

        _isPlaying.value = true
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val stepMs = 50L
            while (_isPlaying.value) {
                delay(stepMs)
                val newTime = _playheadSec.value + (stepMs / 1000.0)
                if (newTime >= endLimit) {
                    _playheadSec.value = project.trimStartSec
                } else {
                    _playheadSec.value = newTime
                }
            }
        }
    }

    fun pausePlayback() {
        _isPlaying.value = false
        playbackJob?.cancel()
    }

    fun seekTo(timeSec: Double) {
        val project = activeProject.value ?: return
        val clamped = timeSec.coerceIn(project.trimStartSec, project.trimEndSec)
        _playheadSec.value = clamped
    }

    fun stepForward() {
        seekTo(_playheadSec.value + 1.0)
    }

    fun stepBackward() {
        seekTo(_playheadSec.value - 1.0)
    }

    // Trimming
    fun updateTrimBounds(startSec: Double, endSec: Double) {
        val current = activeProject.value ?: return
        val validStart = startSec.coerceAtLeast(0.0)
        val validEnd = endSec.coerceAtMost(current.durationSec).coerceAtLeast(validStart + 1.0)
        val updated = current.copy(
            trimStartSec = validStart,
            trimEndSec = validEnd
        )
        repository.updateProject(updated)
        if (_playheadSec.value < validStart || _playheadSec.value > validEnd) {
            _playheadSec.value = validStart
        }
    }

    // Split clip at playhead
    fun splitAtPlayhead(): Boolean {
        val current = activeProject.value ?: return false
        val pos = _playheadSec.value
        if (pos <= current.trimStartSec + 0.5 || pos >= current.trimEndSec - 0.5) return false

        val clip1 = VideoClip(
            title = "Part 1",
            startOffsetSec = current.trimStartSec,
            endOffsetSec = pos,
            sourceDurationSec = current.durationSec
        )
        val clip2 = VideoClip(
            title = "Part 2",
            startOffsetSec = pos,
            endOffsetSec = current.trimEndSec,
            sourceDurationSec = current.durationSec
        )
        val updated = current.copy(clips = listOf(clip1, clip2))
        repository.updateProject(updated)
        return true
    }

    // Text Overlays
    fun addTextOverlay(text: String, style: String = "Impact", colorHex: String = "#FFEB3B") {
        val current = activeProject.value ?: return
        val newOverlay = TextOverlay(
            id = UUID.randomUUID().toString(),
            text = text.ifBlank { "NEW CAPTION" },
            style = style,
            colorHex = colorHex,
            startSec = _playheadSec.value,
            endSec = (_playheadSec.value + 3.0).coerceAtMost(current.durationSec),
            positionYPercent = 0.25f
        )
        val updated = current.copy(textOverlays = current.textOverlays + newOverlay)
        repository.updateProject(updated)
    }

    fun removeTextOverlay(id: String) {
        val current = activeProject.value ?: return
        val updated = current.copy(textOverlays = current.textOverlays.filter { it.id != id })
        repository.updateProject(updated)
    }

    fun updateTextOverlay(overlay: TextOverlay) {
        val current = activeProject.value ?: return
        val updated = current.copy(
            textOverlays = current.textOverlays.map { if (it.id == overlay.id) overlay else it }
        )
        repository.updateProject(updated)
    }

    // Music & Audio Track
    fun setAudioTrack(track: AudioTrack?) {
        val current = activeProject.value ?: return
        val updated = current.copy(audioTrack = track)
        repository.updateProject(updated)
    }

    // Captions & Subtitles
    fun addCaptionItem(text: String) {
        val current = activeProject.value ?: return
        val start = _playheadSec.value
        val end = (start + 2.5).coerceAtMost(current.durationSec)
        val firstWord = text.split(" ").firstOrNull() ?: ""
        val item = CaptionItem(startSec = start, endSec = end, text = text, highlightWord = firstWord)
        val updated = current.copy(captions = current.captions + item)
        repository.updateProject(updated)
    }

    fun removeCaptionItem(id: String) {
        val current = activeProject.value ?: return
        val updated = current.copy(captions = current.captions.filter { it.id != id })
        repository.updateProject(updated)
    }

    // Real Video Export
    fun startExport(config: ExportConfig = ExportConfig()) {
        val project = activeProject.value ?: return
        pausePlayback()
        _exportState.value = VideoExporter.ExportState.Exporting(0f, "Initializing 9:16 export pipeline...")

        viewModelScope.launch {
            val result = videoExporter.exportProject(project, config) { progress, status ->
                _exportState.value = VideoExporter.ExportState.Exporting(progress, status)
            }
            _exportState.value = result
            if (result is VideoExporter.ExportState.Success) {
                val updatedProj = project.copy(exportPath = result.file.absolutePath)
                repository.updateProject(updatedProj)
            }
        }
    }

    fun dismissExportDialog() {
        _exportState.value = VideoExporter.ExportState.Idle
    }

    // Voiceover (TTS)
    fun previewVoiceover(text: String) {
        voiceoverEngine.speak(text, _voiceoverSettings.value)
    }

    fun stopVoiceover() {
        voiceoverEngine.stop()
    }

    fun attachVoiceoverToProject(scriptText: String) {
        val current = activeProject.value ?: return
        val voTrack = AudioTrack(
            id = UUID.randomUUID().toString(),
            title = "AI Voiceover: \"${scriptText.take(24)}...\"",
            artist = "USClips English TTS",
            category = "AI Voiceover",
            durationSec = current.durationSec,
            volume = 0.95f
        )
        val updated = current.copy(audioTrack = voTrack)
        repository.updateProject(updated)
    }

    // AI Tools: Hooks & Captions
    fun generateHooks(topic: String) {
        _hookQuery.value = topic
        _generatedHooks.value = AIToolsService.generateViralHooks(topic)
    }

    fun generateCaptions(topic: String, category: String) {
        _captionTopic.value = topic
        _generatedCaptions.value = AIToolsService.generateTitlesAndCaptions(topic, category)
    }

    // AI Video Generator
    fun setAIGenPrompt(prompt: String) {
        _aiGenPrompt.value = prompt
    }

    fun setAIGenStyle(style: VideoStyle) {
        _aiGenStyle.value = style
    }

    fun setAIGenDuration(duration: Int) {
        _aiGenDuration.value = duration
    }

    fun triggerAIVideoGeneration() {
        val prompt = _aiGenPrompt.value.trim()
        if (prompt.isBlank()) return

        _isGeneratingAIVideo.value = true
        _aiGenStatusMessage.value = "Analyzing cinematic prompt and visual tokens..."
        _aiGenResultProject.value = null

        viewModelScope.launch {
            delay(600)
            _aiGenStatusMessage.value = "Synthesizing 9:16 vertical storyboard frames (${_aiGenStyle.value.displayName})..."
            delay(900)
            _aiGenStatusMessage.value = "Structuring camera motion & 60fps frame interpolation..."
            delay(900)
            _aiGenStatusMessage.value = "Generating viral hook overlays and audio atmosphere..."
            delay(600)

            // Creates a new project from the AI prompt with structured overlays, audio track, and metadata
            val generatedProj = repository.createNewProject(
                title = "AI Gen: ${prompt.take(22)}",
                durationSec = _aiGenDuration.value.toDouble(),
                templateCategory = _aiGenStyle.value.displayName
            )

            val updatedProj = generatedProj.copy(
                textOverlays = listOf(
                    TextOverlay(
                        text = prompt.take(36).uppercase(),
                        style = if (_aiGenStyle.value == VideoStyle.ANIME_CINEMATIC) "Neon" else "Impact",
                        colorHex = if (_aiGenStyle.value == VideoStyle.ANIME_CINEMATIC) "#00F2FE" else "#FFEB3B",
                        positionYPercent = 0.20f,
                        startSec = 0.0,
                        endSec = (_aiGenDuration.value / 2.0)
                    )
                ),
                audioTrack = AudioTrack(
                    title = if (_aiGenStyle.value == VideoStyle.ANIME_CINEMATIC) "Tokyo Drift Phonk (142 BPM)" else "Viral US 808 Drill Kick",
                    category = "AI Generated",
                    durationSec = _aiGenDuration.value.toDouble()
                )
            )
            repository.updateProject(updatedProj)

            _aiGenResultProject.value = updatedProj
            _isGeneratingAIVideo.value = false
            _aiGenStatusMessage.value = "9:16 AI Video Draft Ready!"
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        voiceoverEngine.shutdown()
    }
}
