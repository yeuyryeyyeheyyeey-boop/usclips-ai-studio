package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AiToolsScreen
import com.example.ui.AiVideoGenScreen
import com.example.ui.AnimeTemplatesScreen
import com.example.ui.EditorScreen
import com.example.ui.HomeScreen
import com.example.ui.MyProjectsScreen
import com.example.ui.UsaTemplatesScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.StudioScreen
import com.example.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: StudioViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBg,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    bottomBar = {
                        // Show bottom navigation bar when on top-level screens
                        if (currentScreen != StudioScreen.Editor) {
                            StudioBottomNavigationBar(
                                currentScreen = currentScreen,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DarkBg)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "screenTransition"
                        ) { screen ->
                            when (screen) {
                                is StudioScreen.Home -> HomeScreen(viewModel = viewModel)
                                is StudioScreen.Editor -> EditorScreen(viewModel = viewModel)
                                is StudioScreen.AIVideoGen -> AiVideoGenScreen(viewModel = viewModel)
                                is StudioScreen.AnimeTemplates -> AnimeTemplatesScreen(viewModel = viewModel)
                                is StudioScreen.UsaTemplates -> UsaTemplatesScreen(viewModel = viewModel)
                                is StudioScreen.MyProjects -> MyProjectsScreen(viewModel = viewModel)
                                is StudioScreen.AITools -> AiToolsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudioBottomNavigationBar(
    currentScreen: StudioScreen,
    onNavigate: (StudioScreen) -> Unit
) {
    NavigationBar(
        containerColor = DarkSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("studio_bottom_nav")
    ) {
        val navItems = listOf(
            Triple(StudioScreen.Home, "Home", Icons.Default.Home),
            Triple(StudioScreen.Editor, "Editor", Icons.Default.ContentCut),
            Triple(StudioScreen.AIVideoGen, "AI Gen", Icons.Default.RocketLaunch),
            Triple(StudioScreen.MyProjects, "Projects", Icons.Default.Folder),
            Triple(StudioScreen.AITools, "AI Tools", Icons.Default.Psychology)
        )

        navItems.forEach { (screen, label, icon) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = NeonCyan,
                    indicatorColor = NeonCyan,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}
