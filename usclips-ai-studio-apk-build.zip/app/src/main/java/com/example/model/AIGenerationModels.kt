package com.example.model

enum class VideoStyle(val displayName: String, val promptModifier: String) {
    ANIME_CINEMATIC("Anime Cinematic", "Makoto Shinkai style, vibrant cel shading, high-octane anime composition, 4k detail, dramatic lighting"),
    HYPERREAL("Hyperreal 4K", "Ultra-detailed 8k cinema camera footage, photorealistic, 35mm lens, natural subsurface scattering, volumetric fog"),
    CYBERPUNK("Cyberpunk Neon", "Dark blade runner aesthetic, neon pink and turquoise reflections, wet streets, futuristic holograms, moody smoke"),
    DARK_FANTASY("Dark Fantasy", "Epic cinematic fantasy, gothic lighting, embers floating, misty atmosphere, unreal engine 5 render"),
    RETRO_VHS("Retro 90s VHS", "Nostalgic 1990s VHS camcorder tape distortion, retro chromatic aberration, analog scanlines, gritty film grain")
}

enum class CameraMotion(val displayName: String, val promptModifier: String) {
    DYNAMIC_TRACKING("Dynamic Tracking", "Fast tracking shot following subject motion, energetic camera pan"),
    SLOW_ZOOM("Cinematic Zoom In", "Slow tension-building zoom toward center focal point"),
    ORBIT_360("360° Orbit", "Smooth circular orbital sweep around character"),
    FPV_DRONE("FPV Drone Dive", "High speed acrobatic FPV drone dive through environment"),
    STATIC_DRAMATIC("Static Dramatic", "Locked-off wide angle cinematic frame with intense foreground action")
}

data class AIVideoGenerationRequest(
    val prompt: String,
    val style: VideoStyle = VideoStyle.ANIME_CINEMATIC,
    val durationSec: Int = 10, // 5, 10, 15, 30
    val aspectRatio: String = "9:16",
    val cameraMotion: CameraMotion = CameraMotion.DYNAMIC_TRACKING,
    val seed: Long = 42L
)

data class GeneratedScriptHook(
    val hookText: String,
    val retentionScore: Int, // e.g. 96%
    val psychologicalTrigger: String, // Curiosity, FOMO, Contradiction, Urgency
    val suggestedVoiceTone: String // Energetic, Whispering Mystery, Confident Authority
)

data class GeneratedCaptionBundle(
    val captionText: String,
    val hashtags: List<String>,
    val callToAction: String
)

data class VoiceoverSettings(
    val pitch: Float = 1.0f,
    val speechRate: Float = 1.05f,
    val localeTag: String = "en_US"
)
