package com.example.model

import java.util.UUID

data class TextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val text: String = "YOUR VIRAL HOOK",
    val style: String = "Impact", // Impact, Neon Glow, Clean Sans, Typewriter
    val colorHex: String = "#FFEB3B", // Yellow/White/Cyan
    val bgPillHex: String? = "#CC000000",
    val positionYPercent: Float = 0.25f, // 0.0 top, 0.5 center, 0.8 bottom
    val startSec: Double = 0.0,
    val endSec: Double = 5.0
)

data class AudioTrack(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val artist: String = "USClips Studio",
    val category: String, // Phonk, Trending Beat, Lo-Fi, Suspense, AI Voiceover
    val durationSec: Double = 15.0,
    val volume: Float = 0.85f,
    val uriString: String? = null
)

data class CaptionItem(
    val id: String = UUID.randomUUID().toString(),
    val startSec: Double,
    val endSec: Double,
    val text: String,
    val highlightWord: String = ""
)

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Clip 1",
    val startOffsetSec: Double = 0.0,
    val endOffsetSec: Double = 15.0,
    val sourceDurationSec: Double = 15.0,
    val speed: Float = 1.0f
)

data class VideoProject(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Viral 9:16 Short",
    val createdAt: Long = System.currentTimeMillis(),
    val lastEditedAt: Long = System.currentTimeMillis(),
    val durationSec: Double = 15.0,
    val aspectRatio: String = "9:16",
    val videoUri: String? = null,
    val trimStartSec: Double = 0.0,
    val trimEndSec: Double = 15.0,
    val clips: List<VideoClip> = listOf(VideoClip()),
    val textOverlays: List<TextOverlay> = listOf(
        TextOverlay(text = "WAIT TILL THE END 😱", style = "Impact", colorHex = "#FFEB3B", positionYPercent = 0.2f, startSec = 0.0, endSec = 4.0)
    ),
    val audioTrack: AudioTrack? = AudioTrack(
        title = "Phonk Drift 140BPM",
        category = "Phonk",
        durationSec = 15.0
    ),
    val captions: List<CaptionItem> = listOf(
        CaptionItem(startSec = 0.0, endSec = 2.5, text = "Nobody believed this would happen...", highlightWord = "Nobody"),
        CaptionItem(startSec = 2.5, endSec = 5.5, text = "Until this secret came out!", highlightWord = "secret")
    ),
    val templateCategory: String? = null,
    val exportPath: String? = null
)

data class TemplateItem(
    val id: String,
    val title: String,
    val category: String, // Anime, USA Viral
    val description: String,
    val durationSec: Double,
    val hookTitle: String,
    val recommendedMusic: String,
    val promptTemplate: String,
    val badge: String,
    val bgGradientColors: List<Long>
)

data class ExportConfig(
    val resolution: String = "1080x1920 (9:16 Vertical HD)",
    val frameRate: Int = 30, // 30fps or 60fps
    val bitrateMbps: Int = 12,
    val audioBitrateKbps: Int = 192,
    val format: String = "MP4 (H.264 / AAC)"
)
