package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// USClips AI Studio - Professional Dark Suite Palette
val DarkBg = Color(0xFF090B10)
val DarkSurface = Color(0xFF121620)
val DarkSurfaceVariant = Color(0xFF1B2130)
val DarkBorder = Color(0xFF283144)

// Studio Accent Colors
val NeonCyan = Color(0xFF00F2FE)
val CyanGlow = Color(0xFF4FACFE)
val ElectricViolet = Color(0xFF8A2BE2)
val NeonPurple = Color(0xFFA855F7)
val AccentPink = Color(0xFFFF2E63)
val AccentAmber = Color(0xFFFFB703)
val AccentGreen = Color(0xFF00E676)

// Timeline & Editor Colors
val VideoTrackColor = Color(0xFF2563EB)
val AudioTrackColor = Color(0xFF10B981)
val TextTrackColor = Color(0xFFF59E0B)
val PlayheadColor = Color(0xFF00F2FE)

// Typography Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Template default colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
