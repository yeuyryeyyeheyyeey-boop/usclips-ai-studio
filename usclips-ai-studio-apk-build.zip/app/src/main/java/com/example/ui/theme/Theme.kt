package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF03141B),
    primaryContainer = Color(0xFF0C2E3C),
    onPrimaryContainer = NeonCyan,
    
    secondary = ElectricViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2C134A),
    onSecondaryContainer = NeonPurple,
    
    tertiary = AccentPink,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF3F0B1E),
    onTertiaryContainer = Color(0xFFFFB2C6),
    
    background = DarkBg,
    onBackground = TextPrimary,
    
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    
    outline = DarkBorder,
    outlineVariant = Color(0xFF1E2638)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Always enforce consistent pro dark studio theme
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = Typography,
        content = content
    )
}
