package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AudioCatalog
import com.example.model.AudioTrack
import com.example.model.ExportConfig
import com.example.model.TextOverlay
import com.example.model.VideoProject
import com.example.service.VideoExporter
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentPink
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PlayheadColor
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VideoTrackColor
import com.example.viewmodel.EditorToolTab
import com.example.viewmodel.StudioScreen
import com.example.viewmodel.StudioViewModel

@Composable
fun EditorScreen(
    viewModel: StudioViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateTo(StudioScreen.Home)
    }

    val activeProject by viewModel.activeProject.collectAsState()
    val playheadSec by viewModel.playheadSec.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val activeToolTab by viewModel.activeToolTab.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    var showExportDialog by remember { mutableStateOf(false) }

    if (activeProject == null) {
        Box(modifier = modifier.fillMaxSize().background(DarkBg), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No active project loaded", color = TextSecondary)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { viewModel.navigateTo(StudioScreen.Home) }) {
                    Text("Return Home")
                }
            }
        }
        return
    }

    val project = activeProject!!

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top Navigation & Action Bar
        EditorTopBar(
            title = project.title,
            onBack = { viewModel.navigateTo(StudioScreen.Home) },
            onExportClick = { showExportDialog = true }
        )

        // Main Editor Work Area: 9:16 Canvas & Timeline
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 9:16 Video Canvas Viewport
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                VideoCanvas916(
                    project = project,
                    currentPlayheadSec = playheadSec,
                    isPlaying = isPlaying,
                    onTogglePlay = { viewModel.togglePlayPause() }
                )
            }

            // Timecode & Transport Bar
            TransportControlBar(
                playheadSec = playheadSec,
                durationSec = project.durationSec,
                isPlaying = isPlaying,
                onTogglePlay = { viewModel.togglePlayPause() },
                onStepBack = { viewModel.stepBackward() },
                onStepForward = { viewModel.stepForward() },
                onSeek = { viewModel.seekTo(it) },
                trimStart = project.trimStartSec,
                trimEnd = project.trimEndSec
            )

            // Multi-track Timeline Visualizer
            TimelineTracksView(
                project = project,
                playheadSec = playheadSec,
                onSeek = { viewModel.seekTo(it) }
            )
        }

        // Editor Tool Tabs
        EditorToolTabsBar(
            selectedTab = activeToolTab,
            onTabSelected = { viewModel.setToolTab(it) }
        )

        // Tool Sub-Panel Container
        Surface(
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkBorder),
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
        ) {
            when (activeToolTab) {
                EditorToolTab.TRIM -> TrimToolPanel(project = project, viewModel = viewModel)
                EditorToolTab.SPLIT -> SplitToolPanel(project = project, playheadSec = playheadSec, viewModel = viewModel)
                EditorToolTab.TEXT -> TextToolPanel(project = project, viewModel = viewModel)
                EditorToolTab.MUSIC -> MusicToolPanel(project = project, viewModel = viewModel)
                EditorToolTab.CAPTIONS -> CaptionsToolPanel(project = project, viewModel = viewModel)
                EditorToolTab.EXPORT -> ExportToolPanel(project = project, onStartExport = { showExportDialog = true })
            }
        }
    }

    // Export Confirmation & Progress Modal
    if (showExportDialog) {
        ExportModalDialog(
            project = project,
            exportState = exportState,
            onDismiss = {
                showExportDialog = false
                viewModel.dismissExportDialog()
            },
            onConfirmExport = { config ->
                viewModel.startExport(config)
            }
        )
    }
}

@Composable
fun EditorTopBar(
    title: String,
    onBack: () -> Unit,
    onExportClick: () -> Unit
) {
    Surface(
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("editor_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        ),
                        maxLines = 1
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = NeonCyan.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "9:16 VERTICAL",
                                color = NeonCyan,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "1080x1920",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Button(
                onClick = onExportClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = Color(0xFF03141B)
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("export_mp4_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Export MP4",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Export MP4",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun VideoCanvas916(
    project: VideoProject,
    currentPlayheadSec: Double,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // 9:16 aspect ratio box
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF05070A)),
        border = BorderStroke(2.dp, DarkBorder),
        modifier = Modifier
            .fillMaxHeight(0.98f)
            .aspectRatio(9f / 16f)
            .shadow(12.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onTogglePlay)
            .testTag("canvas_916_preview")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Dynamic Studio Background representing video track
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF101929),
                                Color(0xFF0A0F1A),
                                Color(0xFF140C22)
                            )
                        )
                    )
            )

            // Animated frame grid and aura to simulate live media playback
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(
                                NeonCyan.copy(alpha = if (isPlaying) pulseAlpha * 0.25f else 0.08f),
                                Color.Transparent
                            )
                        )
                    )
            )

            // Simulated Video Media Elements or imported indicator
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!project.videoUri.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = NeonCyan.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🎬 IMPORTED MEDIA SOURCE",
                            color = NeonCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ElectricViolet.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, ElectricViolet.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "STUDIO 9:16 CANVAS",
                            color = ElectricViolet,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Play / Pause central indicator overlay
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Playback state",
                        tint = NeonCyan,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Render Active Text Overlays at their positions
            project.textOverlays.forEach { overlay ->
                val isVisible = currentPlayheadSec >= overlay.startSec && currentPlayheadSec <= overlay.endSec
                if (isVisible) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(overlay.positionYPercent)
                            .align(Alignment.TopCenter)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(android.graphics.Color.parseColor(overlay.bgPillHex ?: "#CC000000")),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 12.dp)
                        ) {
                            Text(
                                text = overlay.text,
                                color = Color(android.graphics.Color.parseColor(overlay.colorHex)),
                                fontSize = if (overlay.style == "Impact") 20.sp else 16.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Render Active Animated Subtitle Captions
            val activeCaption = project.captions.firstOrNull {
                currentPlayheadSec >= it.startSec && currentPlayheadSec <= it.endSec
            }

            activeCaption?.let { cap ->
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 24.dp, start = 16.dp, end = 16.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xDD000000),
                        border = BorderStroke(1.dp, Color(0x44FFFFFF))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            val words = cap.text.split(" ")
                            words.forEach { word ->
                                val isHighlight = word.contains(cap.highlightWord, ignoreCase = true)
                                Text(
                                    text = "$word ",
                                    color = if (isHighlight) AccentAmber else Color.White,
                                    fontWeight = if (isHighlight) FontWeight.Black else FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransportControlBar(
    playheadSec: Double,
    durationSec: Double,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onStepBack: () -> Unit,
    onStepForward: () -> Unit,
    onSeek: (Double) -> Unit,
    trimStart: Double,
    trimEnd: Double
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // Scrubber Slider
        Slider(
            value = playheadSec.toFloat(),
            onValueChange = { onSeek(it.toDouble()) },
            valueRange = 0f..durationSec.toFloat().coerceAtLeast(1f),
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = DarkSurfaceVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("playhead_slider")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Timecode Badge
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = DarkSurface,
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Text(
                    text = "${formatTimecode(playheadSec)} / ${formatTimecode(durationSec)}",
                    color = NeonCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            // Transport Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onStepBack,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "-1s",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NeonCyan)
                        .clickable(onClick = onTogglePlay)
                        .testTag("transport_play_pause_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = onStepForward,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "+1s",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Trim status badge
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = DarkSurface,
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Text(
                    text = "Trim: ${trimStart.toInt()}s - ${trimEnd.toInt()}s",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun TimelineTracksView(
    project: VideoProject,
    playheadSec: Double,
    onSeek: (Double) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color(0xFF07090E),
        border = BorderStroke(1.dp, DarkBorder),
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clickable {
                // Seek on timeline tap
                onSeek(playheadSec)
            }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val totalWidth = maxWidth
            val duration = project.durationSec.coerceAtLeast(1.0)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Track 1: Video Track
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(VideoTrackColor.copy(alpha = 0.4f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCut,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(12.dp).padding(start = 2.dp)
                    )
                    Text(
                        text = " VIDEO: ${project.title}",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                // Track 2: Audio Track
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(AccentGreen.copy(alpha = 0.35f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = AccentGreen,
                        modifier = Modifier.size(12.dp).padding(start = 2.dp)
                    )
                    Text(
                        text = " AUDIO: ${project.audioTrack?.title ?: "No Audio Track"}",
                        color = AccentGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            // Playhead indicator needle
            val playheadRatio = (playheadSec / duration).coerceIn(0.0, 1.0)
            val playheadOffset = totalWidth * playheadRatio.toFloat()

            Box(
                modifier = Modifier
                    .width(2.dp)
                    .fillMaxHeight()
                    .align(Alignment.CenterStart)
                    .padding(start = playheadOffset.coerceAtLeast(0.dp))
                    .background(PlayheadColor)
            )
        }
    }
}

@Composable
fun EditorToolTabsBar(
    selectedTab: EditorToolTab,
    onTabSelected: (EditorToolTab) -> Unit
) {
    val tabs = listOf(
        EditorToolTab.TRIM to "Trim",
        EditorToolTab.SPLIT to "Split",
        EditorToolTab.TEXT to "Text",
        EditorToolTab.MUSIC to "Music",
        EditorToolTab.CAPTIONS to "Captions",
        EditorToolTab.EXPORT to "Export"
    )

    TabRow(
        selectedTabIndex = tabs.indexOfFirst { it.first == selectedTab },
        containerColor = DarkSurface,
        contentColor = NeonCyan,
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                Modifier.tabIndicatorOffset(tabPositions[tabs.indexOfFirst { it.first == selectedTab }]),
                color = NeonCyan
            )
        }
    ) {
        tabs.forEach { (tab, label) ->
            Tab(
                selected = selectedTab == tab,
                onClick = { onTabSelected(tab) },
                text = {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                        color = if (selectedTab == tab) NeonCyan else TextSecondary
                    )
                }
            )
        }
    }
}

// 1. Trim Sub-Panel
@Composable
fun TrimToolPanel(project: VideoProject, viewModel: StudioViewModel) {
    var startTrim by remember(project.trimStartSec) { mutableFloatStateOf(project.trimStartSec.toFloat()) }
    var endTrim by remember(project.trimEndSec) { mutableFloatStateOf(project.trimEndSec.toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("VIDEO TRIM RANGE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontWeight = FontWeight.Bold))
                Text(
                    text = "${"%.1f".format(startTrim)}s  to  ${"%.1f".format(endTrim)}s (${"%.1f".format(endTrim - startTrim)}s total)",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Button(
                onClick = {
                    viewModel.updateTrimBounds(startTrim.toDouble(), endTrim.toDouble())
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Apply Trim", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Dual Range Slider
        RangeSlider(
            value = startTrim..endTrim,
            onValueChange = { range ->
                startTrim = range.start
                endTrim = range.endInclusive
            },
            valueRange = 0f..project.durationSec.toFloat().coerceAtLeast(1f),
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = DarkSurfaceVariant
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(
                onClick = {
                    startTrim = 0f
                    endTrim = project.durationSec.toFloat()
                    viewModel.updateTrimBounds(0.0, project.durationSec)
                },
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Text("Reset Full Length", color = TextSecondary, fontSize = 12.sp)
            }

            OutlinedButton(
                onClick = {
                    // Set 9:16 viral short preset: 15s
                    startTrim = 0f
                    endTrim = 15f.coerceAtMost(project.durationSec.toFloat())
                    viewModel.updateTrimBounds(0.0, endTrim.toDouble())
                },
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
            ) {
                Text("15s Viral Preset", color = NeonCyan, fontSize = 12.sp)
            }
        }
    }
}

// 2. Split Sub-Panel
@Composable
fun SplitToolPanel(project: VideoProject, playheadSec: Double, viewModel: StudioViewModel) {
    var splitMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.ContentCut,
            contentDescription = null,
            tint = NeonCyan,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Split clip at playhead position (${formatTimecode(playheadSec)})",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
        Text(
            text = "Creates two separate clips on the timeline at the exact frame",
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = {
                val success = viewModel.splitAtPlayhead()
                splitMessage = if (success) "Split clip successfully at ${formatTimecode(playheadSec)}!" else "Cannot split at start/end boundary."
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Split Clip Here", fontWeight = FontWeight.Bold)
        }

        splitMessage?.let {
            Spacer(modifier = Modifier.height(6.dp))
            Text(it, color = NeonCyan, fontSize = 11.sp)
        }
    }
}

// 3. Text Overlay Sub-Panel
@Composable
fun TextToolPanel(project: VideoProject, viewModel: StudioViewModel) {
    var newText by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Impact") }
    var selectedColor by remember { mutableStateOf("#FFEB3B") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newText,
                onValueChange = { newText = it },
                placeholder = { Text("Enter viral hook text...", fontSize = 12.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            )

            Button(
                onClick = {
                    if (newText.isNotBlank()) {
                        viewModel.addTextOverlay(newText, selectedStyle, selectedColor)
                        newText = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(50.dp)
            ) {
                Text("Add Text", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Style and Color selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Font Styles
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Impact", "Neon", "Clean").forEach { style ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (selectedStyle == style) NeonCyan.copy(alpha = 0.2f) else DarkSurfaceVariant,
                        border = BorderStroke(1.dp, if (selectedStyle == style) NeonCyan else DarkBorder),
                        modifier = Modifier.clickable { selectedStyle = style }
                    ) {
                        Text(
                            text = style,
                            color = if (selectedStyle == style) NeonCyan else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Colors
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("#FFEB3B", "#FFFFFF", "#00F2FE", "#FF2E63").forEach { hex ->
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(android.graphics.Color.parseColor(hex)))
                            .border(
                                2.dp,
                                if (selectedColor == hex) Color.White else Color.Transparent,
                                CircleShape
                            )
                            .clickable { selectedColor = hex }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Existing Overlays List
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(project.textOverlays) { overlay ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = overlay.text,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove",
                            tint = AccentPink,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { viewModel.removeTextOverlay(overlay.id) }
                        )
                    }
                }
            }
        }
    }
}

// 4. Music Sub-Panel
@Composable
fun MusicToolPanel(project: VideoProject, viewModel: StudioViewModel) {
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val custom = AudioTrack(
                title = "Imported Audio Track",
                artist = "Custom File",
                category = "Imported",
                durationSec = project.durationSec,
                uriString = uri.toString()
            )
            viewModel.setAudioTrack(custom)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE: ${project.audioTrack?.title ?: "No Track"}",
                color = AccentGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )

            OutlinedButton(
                onClick = { audioPicker.launch("audio/*") },
                border = BorderStroke(1.dp, AccentGreen.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Pick Audio", color = AccentGreen, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text("PRESET VIRAL TRACKS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) {
            items(AudioCatalog.presetTracks) { track ->
                val isSelected = project.audioTrack?.id == track.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) AccentGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                    border = BorderStroke(1.dp, if (isSelected) AccentGreen else DarkBorder),
                    modifier = Modifier.clickable { viewModel.setAudioTrack(track) }
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = track.title,
                            color = if (isSelected) AccentGreen else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = track.category,
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

// 5. Captions Sub-Panel
@Composable
fun CaptionsToolPanel(project: VideoProject, viewModel: StudioViewModel) {
    var captionInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = captionInput,
                onValueChange = { captionInput = it },
                placeholder = { Text("Add subtitle line...", fontSize = 12.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentAmber,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            )

            Button(
                onClick = {
                    if (captionInput.isNotBlank()) {
                        viewModel.addCaptionItem(captionInput)
                        captionInput = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("Add", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(project.captions) { cap ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, DarkBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = cap.text,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${"%.1f".format(cap.startSec)}s - ${"%.1f".format(cap.endSec)}s | Highlight: \"${cap.highlightWord}\"",
                                color = AccentAmber,
                                fontSize = 9.sp
                            )
                        }

                        IconButton(
                            onClick = { viewModel.removeCaptionItem(cap.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

// 6. Export Sub-Panel
@Composable
fun ExportToolPanel(project: VideoProject, onStartExport: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "EXPORT 9:16 VERTICAL MP4",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Optimized for TikTok, Instagram Reels, and YouTube Shorts",
                color = TextSecondary,
                fontSize = 11.sp
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurfaceVariant,
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("1080x1920", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Resolution", color = TextMuted, fontSize = 10.sp)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurfaceVariant,
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("30 FPS", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Frame Rate", color = TextMuted, fontSize = 10.sp)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSurfaceVariant,
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("H.264 / AAC", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Codec", color = TextMuted, fontSize = 10.sp)
                }
            }
        }

        Button(
            onClick = onStartExport,
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
        ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Start Export Pipeline", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
fun ExportModalDialog(
    project: VideoProject,
    exportState: VideoExporter.ExportState,
    onDismiss: () -> Unit,
    onConfirmExport: (ExportConfig) -> Unit
) {
    var selectedFps by remember { mutableStateOf(30) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = "Export 9:16 Video",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                when (exportState) {
                    is VideoExporter.ExportState.Idle -> {
                        Text(
                            text = "Render and export \"${project.title}\" as a full 9:16 vertical MP4 video file to device storage.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )

                        Text("Select Framerate:", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(30, 60).forEach { fps ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (selectedFps == fps) NeonCyan.copy(alpha = 0.2f) else DarkSurfaceVariant,
                                    border = BorderStroke(1.dp, if (selectedFps == fps) NeonCyan else DarkBorder),
                                    modifier = Modifier.clickable { selectedFps = fps }
                                ) {
                                    Text(
                                        text = "$fps FPS",
                                        color = if (selectedFps == fps) NeonCyan else TextSecondary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    is VideoExporter.ExportState.Exporting -> {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = NeonCyan)
                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(
                                progress = { exportState.progress },
                                color = NeonCyan,
                                trackColor = DarkSurfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = exportState.statusText,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    is VideoExporter.ExportState.Success -> {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(AccentGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = AccentGreen, modifier = Modifier.size(28.dp))
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Export Completed Successfully!", color = TextPrimary, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("File: ${exportState.file.name}", color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                            Text("Size: ${exportState.fileSizeFormatted} | Duration: ${"%.1f".format(exportState.durationSec)}s", color = NeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Saved in app Movies folder: ${exportState.file.parent}",
                                color = TextMuted,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    is VideoExporter.ExportState.Error -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = AccentPink, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Export Error", color = AccentPink, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(exportState.message, color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (exportState is VideoExporter.ExportState.Idle) {
                Button(
                    onClick = {
                        onConfirmExport(ExportConfig(frameRate = selectedFps))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                ) {
                    Text("Export MP4 Now")
                }
            } else if (exportState is VideoExporter.ExportState.Success || exportState is VideoExporter.ExportState.Error) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                ) {
                    Text("Done")
                }
            }
        },
        dismissButton = {
            if (exportState is VideoExporter.ExportState.Idle) {
                OutlinedButton(onClick = onDismiss) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        }
    )
}

fun formatTimecode(seconds: Double): String {
    val totalMs = (seconds * 1000).toLong().coerceAtLeast(0)
    val mins = (totalMs / 60000)
    val secs = (totalMs % 60000) / 1000
    val ms = (totalMs % 1000) / 10
    return "%02d:%02d.%02d".format(mins, secs, ms)
}
