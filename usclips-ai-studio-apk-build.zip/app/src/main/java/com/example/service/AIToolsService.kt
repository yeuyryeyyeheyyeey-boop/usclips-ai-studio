package com.example.service

import com.example.model.AIVideoGenerationRequest
import com.example.model.GeneratedCaptionBundle
import com.example.model.GeneratedScriptHook
import com.example.model.VideoStyle

object AIToolsService {

    fun generateViralHooks(topic: String): List<GeneratedScriptHook> {
        val cleanTopic = if (topic.isBlank()) "secret life hacks" else topic.trim()
        return listOf(
            GeneratedScriptHook(
                hookText = "Stop scrolling if you care about $cleanTopic. Nobody is talking about this.",
                retentionScore = 98,
                psychologicalTrigger = "FOMO & Urgency",
                suggestedVoiceTone = "Intense, Whispered Authority"
            ),
            GeneratedScriptHook(
                hookText = "Everything they told you about $cleanTopic was a complete lie.",
                retentionScore = 96,
                psychologicalTrigger = "Contradiction & Curiosity",
                suggestedVoiceTone = "Confident, Punchy Pace"
            ),
            GeneratedScriptHook(
                hookText = "This 1 single shift in $cleanTopic will save you at least 3 hours today.",
                retentionScore = 94,
                psychologicalTrigger = "High Value Proposition",
                suggestedVoiceTone = "Energetic, Fast"
            ),
            GeneratedScriptHook(
                hookText = "I tested 10 different ways of doing $cleanTopic, and only ONE worked.",
                retentionScore = 92,
                psychologicalTrigger = "Social Proof & Test Results",
                suggestedVoiceTone = "Storyteller, Engaging"
            ),
            GeneratedScriptHook(
                hookText = "POV: You finally unlocked the truth about $cleanTopic at 2 AM.",
                retentionScore = 95,
                psychologicalTrigger = "Relatable POV",
                suggestedVoiceTone = "Casual, Relatable"
            )
        )
    }

    fun generateTitlesAndCaptions(topic: String, category: String = "Viral"): GeneratedCaptionBundle {
        val clean = if (topic.isBlank()) "Viral Video Edit" else topic.trim()
        val hashtags = when (category) {
            "Anime" -> listOf("#USClips", "#AnimeEdit", "#AnimeReels", "#Cyberpunk", "#AMV", "#ViralAnime", "#AnimeShorts", "#Otaku")
            "Tech" -> listOf("#USClips", "#TechTips", "#AIStudio", "#TechHacks", "#Gadgets", "#FutureTech", "#Shorts")
            else -> listOf("#USClips", "#fyp", "#viral", "#foryou", "#shorts", "#trending", "#USAtrends", "#reelviral")
        }

        val caption = "Wait until the very end... 🤯 Is this the wildest breakdown on $clean you've seen yet?\n\nSave this for later & share with someone who needs to see this! 👇"
        val cta = "Comment your thoughts below and subscribe for daily viral clips!"

        return GeneratedCaptionBundle(
            captionText = caption,
            hashtags = hashtags,
            callToAction = cta
        )
    }

    fun buildCinematicPrompt(request: AIVideoGenerationRequest): String {
        val sb = StringBuilder()
        sb.append(request.prompt.trim())
        sb.append(", ")
        sb.append(request.style.promptModifier)
        sb.append(", ")
        sb.append(request.cameraMotion.promptModifier)
        sb.append(", vertical ${request.aspectRatio} format, dynamic color grade, master cinematic composition, high shutter speed, 60fps ultra fluid motion")
        return sb.toString()
    }
}
