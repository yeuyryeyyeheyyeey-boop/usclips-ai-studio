package com.example.data

import com.example.model.TemplateItem

object TemplateCatalog {
    val animeTemplates = listOf(
        TemplateItem(
            id = "anime_neo_tokyo",
            title = "Neo-Tokyo Cyber Awakening",
            category = "Anime",
            description = "High-octane cyberpunk anime reel with speed cuts, neon lighting, and dramatic bass drop timing.",
            durationSec = 15.0,
            hookTitle = "HE DIDN'T KNOW HIS POWER WAS AWAKENED ⚡",
            recommendedMusic = "Cyber Drift Phonk (142 BPM)",
            promptTemplate = "Cinematic cyberpunk anime hero with glowing azure eyes standing atop a rainy skyscraper overlooking neon Tokyo 2142, lightning reflecting on katana blade, makoto shinkai aesthetic, 4k 60fps",
            badge = "🔥 TRENDING ANIME",
            bgGradientColors = listOf(0xFF0F172A, 0xFF3B0764, 0xFF06B6D4)
        ),
        TemplateItem(
            id = "anime_manga_cut",
            title = "Manga Panel Breakout",
            category = "Anime",
            description = "Dynamic monochrome manga panel that explodes into full animated neon color on the beat drop.",
            durationSec = 12.0,
            hookTitle = "WHEN THE ANIMATION BUDGET MULTIPLIES BY 10X 💥",
            recommendedMusic = "Tokyo Trap Beat (135 BPM)",
            promptTemplate = "Manga ink drawing panel shattering into colorful anime combat scene with aura shockwaves and dimensional rift, extreme camera zoom, hyper-detailed",
            badge = "⚡ VIRAL EDIT",
            bgGradientColors = listOf(0xFF18181B, 0xFF4C0519, 0xFFE11D48)
        ),
        TemplateItem(
            id = "anime_lofi_vibes",
            title = "Midnight Lofi Tokyo Thoughts",
            category = "Anime",
            description = "Emotional late-night anime aesthetic with rain on train window and relatable deep quote overlays.",
            durationSec = 15.0,
            hookTitle = "Send this to someone you miss at 2 AM 🌙",
            recommendedMusic = "Midnight Rain Lo-Fi Chill",
            promptTemplate = "Aesthetic retro 90s anime girl looking out train window at misty neon rain reflections, melancholic nostalgic mood, studio ghibli lighting",
            badge = "⭐ TOP SAVED",
            bgGradientColors = listOf(0xFF0F172A, 0xFF1E1B4B, 0xFF818CF8)
        ),
        TemplateItem(
            id = "anime_shonen_power",
            title = "God-Mode Transformation",
            category = "Anime",
            description = "Cinematic slow-motion aura buildup culminating in an earth-shattering power release.",
            durationSec = 10.0,
            hookTitle = "BRO REACHED FINAL FORM 😱🔥",
            recommendedMusic = "Heavy Bass Doom Phonk",
            promptTemplate = "Anime warrior ascending with golden lightning aura, ground fracturing beneath boots, dramatic low-angle hero shot, ufotable particle quality",
            badge = "🔥 2.4M REELS",
            bgGradientColors = listOf(0xFF1C1917, 0xFF78350F, 0xFFF59E0B)
        )
    )

    val usaViralTemplates = listOf(
        TemplateItem(
            id = "viral_hook_loop",
            title = "The 3-Second Retention Hook",
            category = "USA Viral",
            description = "Engineered for 100%+ completion rate on US TikTok & Reels with question-hook and fast-paced B-roll.",
            durationSec = 15.0,
            hookTitle = "99% OF PEOPLE GET THIS WRONG... 👀",
            recommendedMusic = "Trending TikTok Fast Kick",
            promptTemplate = "Close-up macro of an intriguing mysterious glowing digital key turning in an ancient futuristic vault door, cinematic suspense",
            badge = "⚡ 98% RETENTION",
            bgGradientColors = listOf(0xFF022C22, 0xFF065F46, 0xFF10B981)
        ),
        TemplateItem(
            id = "viral_reddit_story",
            title = "Reddit Drama Storyteller",
            category = "USA Viral",
            description = "Sensational story reel with animated yellow word-by-word subtitles and tense background atmosphere.",
            durationSec = 30.0,
            hookTitle = "AITA for canceling my sister's wedding? 🍿",
            recommendedMusic = "Dark Atmospheric Tension Hit",
            promptTemplate = "Dramatic dark interior of luxury courtroom with sunlight streaming through dust motes, cinematic mystery lighting",
            badge = "🔥 TOP STORY FORMAT",
            bgGradientColors = listOf(0xFF1E1B4B, 0xFF312E81, 0xFF6366F1)
        ),
        TemplateItem(
            id = "viral_mind_facts",
            title = "Top 3 Mind-Bending Facts",
            category = "USA Viral",
            description = "High velocity trivia format with countdown sound effect markers and zoom-in transitions.",
            durationSec = 20.0,
            hookTitle = "3 facts that will keep you awake tonight 🤯",
            recommendedMusic = "Cyber Tech Pulse (128 BPM)",
            promptTemplate = "Deep ocean abyssal zone glowing jellyfish descending into infinite dark void, surreal hyperrealistic underwater documentary",
            badge = "⭐ HIGH CTR",
            bgGradientColors = listOf(0xFF082F49, 0xFF0369A1, 0xFF38BDF8)
        ),
        TemplateItem(
            id = "viral_pov_relatable",
            title = "POV: When Reality Glitches",
            category = "USA Viral",
            description = "Ultra relatable POV short with witty on-screen text punchlines and bouncy typography.",
            durationSec = 10.0,
            hookTitle = "POV: You realized Monday is tomorrow 😭",
            recommendedMusic = "Viral Comedy Accent Beat",
            promptTemplate = "Person sitting at desk frozen in disbelief looking directly into camera with comedic cinematic lighting and slight slow-mo",
            badge = "🔥 5M+ VIEWS",
            bgGradientColors = listOf(0xFF431407, 0xFF9A3412, 0xFFFB923C)
        )
    )

    val allTemplates = animeTemplates + usaViralTemplates
}
