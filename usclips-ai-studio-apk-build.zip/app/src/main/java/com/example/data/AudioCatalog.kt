package com.example.data

import com.example.model.AudioTrack

object AudioCatalog {
    val presetTracks = listOf(
        AudioTrack(
            id = "audio_phonk_142",
            title = "Tokyo Drift Phonk (142 BPM)",
            artist = "USClips SoundLab",
            category = "Phonk",
            durationSec = 15.0,
            volume = 0.85f
        ),
        AudioTrack(
            id = "audio_synth_wave",
            title = "Cyber Synth Pulse 80s",
            artist = "Neon Skyline",
            category = "Synthwave",
            durationSec = 20.0,
            volume = 0.80f
        ),
        AudioTrack(
            id = "audio_tiktok_trap",
            title = "Viral US 808 Drill Kick",
            artist = "Metro Beat",
            category = "Trending Beat",
            durationSec = 15.0,
            volume = 0.90f
        ),
        AudioTrack(
            id = "audio_lofi_midnight",
            title = "Midnight Coffee Lo-Fi",
            artist = "Rainy Street",
            category = "Lo-Fi",
            durationSec = 30.0,
            volume = 0.75f
        ),
        AudioTrack(
            id = "audio_dark_suspense",
            title = "Tension Revelation Hit",
            artist = "Cinema FX",
            category = "Suspense",
            durationSec = 12.0,
            volume = 0.85f
        ),
        AudioTrack(
            id = "audio_anime_hype",
            title = "Shonen Awakening Rock/Bass",
            artist = "Overdrive",
            category = "Anime",
            durationSec = 15.0,
            volume = 0.90f
        )
    )
}
