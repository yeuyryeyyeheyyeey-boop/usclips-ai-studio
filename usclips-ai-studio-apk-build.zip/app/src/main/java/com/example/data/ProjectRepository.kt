package com.example.data

import android.content.Context
import com.example.model.AudioTrack
import com.example.model.CaptionItem
import com.example.model.TextOverlay
import com.example.model.VideoClip
import com.example.model.VideoProject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("usclips_projects_store", Context.MODE_PRIVATE)
    private val projectsFile = File(context.filesDir, "projects_data.json")

    private val _projects = MutableStateFlow<List<VideoProject>>(emptyList())
    val projects: StateFlow<List<VideoProject>> = _projects.asStateFlow()

    private val _activeProject = MutableStateFlow<VideoProject?>(null)
    val activeProject: StateFlow<VideoProject?> = _activeProject.asStateFlow()

    init {
        loadProjects()
    }

    private fun loadProjects() {
        val loaded = mutableListOf<VideoProject>()
        if (projectsFile.exists()) {
            try {
                val jsonString = projectsFile.readText()
                val jsonArray = JSONArray(jsonString)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    loaded.add(deserializeProject(obj))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (loaded.isEmpty()) {
            // Seed starter projects so the user immediately has high quality pro projects to explore
            val starter1 = VideoProject(
                id = "starter_anime_1",
                title = "Cyber Samurai - 9:16 Short",
                createdAt = System.currentTimeMillis() - 86400000,
                lastEditedAt = System.currentTimeMillis() - 3600000,
                durationSec = 15.0,
                trimStartSec = 0.0,
                trimEndSec = 15.0,
                clips = listOf(VideoClip(title = "Opening Cut", endOffsetSec = 15.0, sourceDurationSec = 15.0)),
                textOverlays = listOf(
                    TextOverlay(
                        text = "POV: HE DISCOVERED THE FORBIDDEN KATANA ⚔️",
                        style = "Neon",
                        colorHex = "#00F2FE",
                        bgPillHex = "#CC0D1117",
                        positionYPercent = 0.22f,
                        startSec = 0.0,
                        endSec = 5.0
                    )
                ),
                audioTrack = AudioTrack(
                    title = "Tokyo Drift Phonk (142 BPM)",
                    category = "Phonk",
                    durationSec = 15.0
                ),
                captions = listOf(
                    CaptionItem(startSec = 0.0, endSec = 3.0, text = "Legends spoke of one blade...", highlightWord = "blade"),
                    CaptionItem(startSec = 3.0, endSec = 6.0, text = "That could split neon lightning!", highlightWord = "lightning")
                ),
                templateCategory = "Anime"
            )

            val starter2 = VideoProject(
                id = "starter_viral_2",
                title = "Top 3 Secrets Nobody Told You",
                createdAt = System.currentTimeMillis() - 172800000,
                lastEditedAt = System.currentTimeMillis() - 7200000,
                durationSec = 12.0,
                trimStartSec = 0.0,
                trimEndSec = 12.0,
                clips = listOf(VideoClip(title = "Secret Hook", endOffsetSec = 12.0, sourceDurationSec = 12.0)),
                textOverlays = listOf(
                    TextOverlay(
                        text = "STOP SCROLLING IF YOU ARE IN THE US 🚨",
                        style = "Impact",
                        colorHex = "#FFEB3B",
                        bgPillHex = "#EE000000",
                        positionYPercent = 0.20f,
                        startSec = 0.0,
                        endSec = 4.0
                    )
                ),
                audioTrack = AudioTrack(
                    title = "Viral US 808 Drill Kick",
                    category = "Trending Beat",
                    durationSec = 12.0
                ),
                captions = listOf(
                    CaptionItem(startSec = 0.0, endSec = 2.5, text = "This one mistake costs millions...", highlightWord = "costs"),
                    CaptionItem(startSec = 2.5, endSec = 6.0, text = "Here is what top creators do instead.", highlightWord = "creators")
                ),
                templateCategory = "USA Viral"
            )

            loaded.add(starter1)
            loaded.add(starter2)
            saveProjectsToFile(loaded)
        }

        _projects.value = loaded
        _activeProject.value = loaded.firstOrNull()
    }

    private fun saveProjectsToFile(list: List<VideoProject>) {
        try {
            val jsonArray = JSONArray()
            for (p in list) {
                jsonArray.put(serializeProject(p))
            }
            projectsFile.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setActiveProject(project: VideoProject) {
        _activeProject.value = project
    }

    fun createNewProject(
        title: String = "Untitled Short",
        videoUri: String? = null,
        durationSec: Double = 15.0,
        templateCategory: String? = null
    ): VideoProject {
        val newProj = VideoProject(
            id = UUID.randomUUID().toString(),
            title = title.ifBlank { "Untitled Short" },
            createdAt = System.currentTimeMillis(),
            lastEditedAt = System.currentTimeMillis(),
            durationSec = durationSec,
            videoUri = videoUri,
            trimStartSec = 0.0,
            trimEndSec = durationSec,
            clips = listOf(VideoClip(title = "Main Track", endOffsetSec = durationSec, sourceDurationSec = durationSec)),
            templateCategory = templateCategory,
            textOverlays = listOf(
                TextOverlay(
                    text = if (templateCategory == "Anime") "UNLEASH THE FINAL FORM 🔥" else "WAIT TILL THE END 👀",
                    colorHex = "#FFEB3B"
                )
            )
        )
        val updated = listOf(newProj) + _projects.value
        _projects.value = updated
        _activeProject.value = newProj
        saveProjectsToFile(updated)
        return newProj
    }

    fun createFromTemplate(template: com.example.model.TemplateItem): VideoProject {
        val newProj = VideoProject(
            id = UUID.randomUUID().toString(),
            title = template.title,
            createdAt = System.currentTimeMillis(),
            lastEditedAt = System.currentTimeMillis(),
            durationSec = template.durationSec,
            trimStartSec = 0.0,
            trimEndSec = template.durationSec,
            clips = listOf(VideoClip(title = template.title, endOffsetSec = template.durationSec, sourceDurationSec = template.durationSec)),
            textOverlays = listOf(
                TextOverlay(
                    text = template.hookTitle,
                    style = if (template.category == "Anime") "Neon" else "Impact",
                    colorHex = if (template.category == "Anime") "#00F2FE" else "#FFEB3B",
                    positionYPercent = 0.22f,
                    startSec = 0.0,
                    endSec = 5.0
                )
            ),
            audioTrack = AudioTrack(
                title = template.recommendedMusic,
                category = template.category,
                durationSec = template.durationSec
            ),
            captions = listOf(
                CaptionItem(startSec = 0.0, endSec = 3.0, text = template.description, highlightWord = template.title.split(" ").firstOrNull() ?: "")
            ),
            templateCategory = template.category
        )
        val updated = listOf(newProj) + _projects.value
        _projects.value = updated
        _activeProject.value = newProj
        saveProjectsToFile(updated)
        return newProj
    }

    fun updateProject(updated: VideoProject) {
        val proj = updated.copy(lastEditedAt = System.currentTimeMillis())
        val list = _projects.value.map { if (it.id == proj.id) proj else it }
        _projects.value = list
        if (_activeProject.value?.id == proj.id) {
            _activeProject.value = proj
        }
        saveProjectsToFile(list)
    }

    fun deleteProject(projectId: String) {
        val list = _projects.value.filter { it.id != projectId }
        _projects.value = list
        if (_activeProject.value?.id == projectId) {
            _activeProject.value = list.firstOrNull()
        }
        saveProjectsToFile(list)
    }

    fun duplicateProject(projectId: String): VideoProject? {
        val source = _projects.value.find { it.id == projectId } ?: return null
        val dup = source.copy(
            id = UUID.randomUUID().toString(),
            title = "${source.title} (Copy)",
            createdAt = System.currentTimeMillis(),
            lastEditedAt = System.currentTimeMillis()
        )
        val updated = listOf(dup) + _projects.value
        _projects.value = updated
        _activeProject.value = dup
        saveProjectsToFile(updated)
        return dup
    }

    // JSON serialization helpers
    private fun serializeProject(p: VideoProject): JSONObject {
        val obj = JSONObject()
        obj.put("id", p.id)
        obj.put("title", p.title)
        obj.put("createdAt", p.createdAt)
        obj.put("lastEditedAt", p.lastEditedAt)
        obj.put("durationSec", p.durationSec)
        obj.put("aspectRatio", p.aspectRatio)
        obj.put("videoUri", p.videoUri ?: "")
        obj.put("trimStartSec", p.trimStartSec)
        obj.put("trimEndSec", p.trimEndSec)
        obj.put("templateCategory", p.templateCategory ?: "")
        obj.put("exportPath", p.exportPath ?: "")

        val textArray = JSONArray()
        for (t in p.textOverlays) {
            val to = JSONObject()
            to.put("id", t.id)
            to.put("text", t.text)
            to.put("style", t.style)
            to.put("colorHex", t.colorHex)
            to.put("bgPillHex", t.bgPillHex ?: "")
            to.put("positionYPercent", t.positionYPercent.toDouble())
            to.put("startSec", t.startSec)
            to.put("endSec", t.endSec)
            textArray.put(to)
        }
        obj.put("textOverlays", textArray)

        p.audioTrack?.let { a ->
            val ao = JSONObject()
            ao.put("id", a.id)
            ao.put("title", a.title)
            ao.put("artist", a.artist)
            ao.put("category", a.category)
            ao.put("durationSec", a.durationSec)
            ao.put("volume", a.volume.toDouble())
            ao.put("uriString", a.uriString ?: "")
            obj.put("audioTrack", ao)
        }

        val capsArray = JSONArray()
        for (c in p.captions) {
            val co = JSONObject()
            co.put("id", c.id)
            co.put("startSec", c.startSec)
            co.put("endSec", c.endSec)
            co.put("text", c.text)
            co.put("highlightWord", c.highlightWord)
            capsArray.put(co)
        }
        obj.put("captions", capsArray)

        return obj
    }

    private fun deserializeProject(obj: JSONObject): VideoProject {
        val texts = mutableListOf<TextOverlay>()
        if (obj.has("textOverlays")) {
            val ta = obj.getJSONArray("textOverlays")
            for (i in 0 until ta.length()) {
                val to = ta.getJSONObject(i)
                texts.add(
                    TextOverlay(
                        id = to.optString("id", UUID.randomUUID().toString()),
                        text = to.optString("text", "Text"),
                        style = to.optString("style", "Impact"),
                        colorHex = to.optString("colorHex", "#FFEB3B"),
                        bgPillHex = to.optString("bgPillHex", "").ifEmpty { null },
                        positionYPercent = to.optDouble("positionYPercent", 0.25).toFloat(),
                        startSec = to.optDouble("startSec", 0.0),
                        endSec = to.optDouble("endSec", 5.0)
                    )
                )
            }
        }

        var audioTrack: AudioTrack? = null
        if (obj.has("audioTrack")) {
            val ao = obj.getJSONObject("audioTrack")
            audioTrack = AudioTrack(
                id = ao.optString("id", UUID.randomUUID().toString()),
                title = ao.optString("title", "Beat"),
                artist = ao.optString("artist", "USClips"),
                category = ao.optString("category", "Trending"),
                durationSec = ao.optDouble("durationSec", 15.0),
                volume = ao.optDouble("volume", 0.85).toFloat(),
                uriString = ao.optString("uriString", "").ifEmpty { null }
            )
        }

        val captions = mutableListOf<CaptionItem>()
        if (obj.has("captions")) {
            val ca = obj.getJSONArray("captions")
            for (i in 0 until ca.length()) {
                val co = ca.getJSONObject(i)
                captions.add(
                    CaptionItem(
                        id = co.optString("id", UUID.randomUUID().toString()),
                        startSec = co.optDouble("startSec", 0.0),
                        endSec = co.optDouble("endSec", 3.0),
                        text = co.optString("text", ""),
                        highlightWord = co.optString("highlightWord", "")
                    )
                )
            }
        }

        return VideoProject(
            id = obj.getString("id"),
            title = obj.getString("title"),
            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
            lastEditedAt = obj.optLong("lastEditedAt", System.currentTimeMillis()),
            durationSec = obj.optDouble("durationSec", 15.0),
            aspectRatio = obj.optString("aspectRatio", "9:16"),
            videoUri = obj.optString("videoUri", "").ifEmpty { null },
            trimStartSec = obj.optDouble("trimStartSec", 0.0),
            trimEndSec = obj.optDouble("trimEndSec", 15.0),
            templateCategory = obj.optString("templateCategory", "").ifEmpty { null },
            exportPath = obj.optString("exportPath", "").ifEmpty { null },
            textOverlays = texts,
            audioTrack = audioTrack,
            captions = captions
        )
    }
}
