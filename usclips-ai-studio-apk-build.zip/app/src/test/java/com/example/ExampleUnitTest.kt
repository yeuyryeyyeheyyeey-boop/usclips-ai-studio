package com.example

import com.example.data.AudioCatalog
import com.example.data.TemplateCatalog
import com.example.model.AIVideoGenerationRequest
import com.example.model.CameraMotion
import com.example.model.VideoStyle
import com.example.service.AIToolsService
import com.example.ui.formatTimecode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testFormatTimecode() {
        assertEquals("00:00.00", formatTimecode(0.0))
        assertEquals("00:03.45", formatTimecode(3.45))
        assertEquals("01:05.00", formatTimecode(65.0))
    }

    @Test
    fun testGenerateViralHooks() {
        val hooks = AIToolsService.generateViralHooks("AI Video Editing")
        assertEquals(5, hooks.size)
        assertTrue(hooks.any { it.retentionScore >= 95 })
        assertTrue(hooks.any { it.hookText.contains("AI Video Editing") })
    }

    @Test
    fun testGenerateTitlesAndCaptions() {
        val bundle = AIToolsService.generateTitlesAndCaptions("Anime Battle", "Anime")
        assertFalse(bundle.captionText.isEmpty())
        assertTrue(bundle.hashtags.contains("#AnimeEdit"))
        assertTrue(bundle.hashtags.contains("#USClips"))
    }

    @Test
    fun testBuildCinematicPrompt() {
        val req = AIVideoGenerationRequest(
            prompt = "Cyber samurai in rain",
            style = VideoStyle.ANIME_CINEMATIC,
            durationSec = 15,
            aspectRatio = "9:16",
            cameraMotion = CameraMotion.DYNAMIC_TRACKING
        )
        val prompt = AIToolsService.buildCinematicPrompt(req)
        assertTrue(prompt.contains("Cyber samurai in rain"))
        assertTrue(prompt.contains("9:16"))
        assertTrue(prompt.contains("Makoto Shinkai style"))
    }

    @Test
    fun testTemplateCatalogsNotEmpty() {
        assertTrue(TemplateCatalog.animeTemplates.isNotEmpty())
        assertTrue(TemplateCatalog.usaViralTemplates.isNotEmpty())
        assertTrue(AudioCatalog.presetTracks.isNotEmpty())
    }
}
